document.addEventListener('DOMContentLoaded', () => {

    // Riferimenti agli elementi HTML
    const monthDisplay = document.getElementById('current-month-display');
    const prevMonthBtn = document.getElementById('prev-month-btn');
    const nextMonthBtn = document.getElementById('next-month-btn');
    const calendarContainer = document.getElementById('monthly-summary-container');

    // Controllo di sicurezza per assicurarsi che tutti gli elementi esistano
    if (!monthDisplay || !prevMonthBtn || !nextMonthBtn || !calendarContainer) {
        console.error("Errore critico: elementi HTML non trovati.");
        return;
    }

    let currentDate = new Date();
    
    // --- NUOVA LOGICA DI SALVATAGGIO ---
    // Prova a caricare i dati salvati dal browser. Se non ci sono, usa un oggetto vuoto.
    let timestamps = loadTimestamps();

    /**
     * Carica le timbrature salvate dalla memoria locale del browser (localStorage).
     * @returns {object} L'oggetto con le timbrature o un oggetto vuoto.
     */
    function loadTimestamps() {
        const savedData = localStorage.getItem('timbratureApp');
        return savedData ? JSON.parse(savedData) : {};
    }

    /**
     * Salva l'oggetto delle timbrature nella memoria locale del browser.
     */
    function saveTimestamps() {
        localStorage.setItem('timbratureApp', JSON.stringify(timestamps));
    }
    // --- FINE NUOVA LOGICA DI SALVATAGGIO ---


    /**
     * Funzione principale che disegna il calendario a schermo.
     */
    const renderCalendar = () => {
        calendarContainer.innerHTML = '';
        currentDate.setDate(1);

        const monthName = currentDate.toLocaleString('it-IT', { month: 'long' });
        const year = currentDate.getFullYear();
        monthDisplay.textContent = `${monthName.charAt(0).toUpperCase() + monthName.slice(1)} ${year}`;

        const daysInMonth = new Date(year, currentDate.getMonth() + 1, 0).getDate();
        const firstDayIndex = (new Date(year, currentDate.getMonth(), 1).getDay() + 6) % 7;

        const calendarGrid = document.createElement('div');
        calendarGrid.className = 'calendar-grid';

        // Aggiunge celle vuote per l'allineamento all'inizio del mese
        for (let i = 0; i < firstDayIndex; i++) {
            calendarGrid.appendChild(document.createElement('div'));
        }

        // Crea una cella per ogni giorno del mese
        for (let day = 1; day <= daysInMonth; day++) {
            const dayCell = document.createElement('div');
            dayCell.className = 'day-cell';
            const today = new Date();
            // Evidenzia il giorno corrente
            if (day === today.getDate() && currentDate.getMonth() === today.getMonth() && year === today.getFullYear()) {
                dayCell.classList.add('today');
            }

            const date = new Date(year, currentDate.getMonth(), day);
            const dayName = date.toLocaleString('it-IT', { weekday: 'short' });
            // Crea una chiave unica per ogni giorno, es: "2025-5-10"
            const dateKey = `${year}-${currentDate.getMonth()}-${day}`;

            // Controlla se ci sono dati salvati per questo giorno
            const entryTime = timestamps[dateKey] ? timestamps[dateKey].entry : '--:--';
            const exitTime = timestamps[dateKey] ? timestamps[dateKey].exit : '--:--';
            
            dayCell.innerHTML = `
                <div class="day-header">
                    <span>${day}</span>
                    <span>${dayName.charAt(0).toUpperCase() + dayName.slice(1)}</span>
                </div>
                <div class="day-body">
                    <p>Entrata: <span class="entry-time">${entryTime}</span></p>
                    <p>Uscita: <span class="exit-time">${exitTime}</span></p>
                </div>
                <div class="day-footer">
                    <button class="timestamp-btn" data-day="${day}">Timbra</button>
                </div>
            `;
            calendarGrid.appendChild(dayCell);
        }

        calendarContainer.appendChild(calendarGrid);
        // Aggiunge gli ascoltatori di eventi ai nuovi pulsanti "Timbra"
        addTimbraEventListeners();
    };

    /**
     * Aggiunge la funzionalità ai pulsanti "Timbra".
     */
    const addTimbraEventListeners = () => {
        document.querySelectorAll('.timestamp-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                const day = e.target.getAttribute('data-day');
                const year = currentDate.getFullYear();
                const month = currentDate.getMonth();
                const dateKey = `${year}-${month}-${day}`;

                // Se non esiste un record per questo giorno, crealo
                if (!timestamps[dateKey]) {
                    timestamps[dateKey] = { entry: null, exit: null };
                }

                const now = new Date();
                const timeString = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

                const dayCell = e.target.closest('.day-cell');
                // Se non c'è l'entrata, registra l'entrata
                if (!timestamps[dateKey].entry) {
                    timestamps[dateKey].entry = timeString;
                    dayCell.querySelector('.entry-time').textContent = timeString;
                // Se c'è l'entrata ma non l'uscita, registra l'uscita
                } else if (!timestamps[dateKey].exit) {
                    timestamps[dateKey].exit = timeString;
                    dayCell.querySelector('.exit-time').textContent = timeString;
                // Se sono già presenti, resetta e registra una nuova entrata
                } else { 
                     timestamps[dateKey] = { entry: timeString, exit: null };
                     dayCell.querySelector('.entry-time').textContent = timeString;
                     dayCell.querySelector('.exit-time').textContent = '--:--';
                }

                // Ogni volta che si timbra, salva tutti i dati
                saveTimestamps();
            });
        });
    };

    // Eventi per i pulsanti di navigazione del mese
    prevMonthBtn.addEventListener('click', () => {
        currentDate.setMonth(currentDate.getMonth() - 1);
        renderCalendar();
    });

    nextMonthBtn.addEventListener('click', () => {
        currentDate.setMonth(currentDate.getMonth() + 1);
        renderCalendar();
    });

    // Disegna il calendario per la prima volta quando la pagina è pronta
    renderCalendar();
});
